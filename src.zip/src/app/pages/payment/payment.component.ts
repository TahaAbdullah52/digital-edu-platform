import { Component } from '@angular/core';
import { PrimButtonComponent } from "../../components/prim-button/prim-button.component";

@Component({
  selector: 'app-payment',
  imports: [PrimButtonComponent],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.scss'
})
export class PaymentComponent {

}
