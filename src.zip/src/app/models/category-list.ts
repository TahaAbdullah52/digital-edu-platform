export interface category_item{
    id: number;
    title: string;
    imagePath: string;
    noOfCourses: number;
}