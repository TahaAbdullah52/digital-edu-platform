export interface story_item{
    id: number;
    desc: string;
    user: string;
    batch_name: string;
    batch_no:number
}